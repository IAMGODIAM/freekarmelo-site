FREE KARMELO — SUPPORTER GRAPHICS KIT
E5 Enclave Incorporated · BDI · #BelieveKarmelo #FreeKarmelo

16 ready-to-post graphics in every format:
  • Square (1080)      — fk_square_1..5.png
  • Story (1080x1920)  — fk_story_1..3.png
  • Wide (1600x900)    — fk_wide_1..3.png
  • Carousel (1080x1350) — fk_carousel_1..5.png

Support him, don't expose him.
Please do NOT post his mugshot or any mailing address.

By Grace, perfect ways.
